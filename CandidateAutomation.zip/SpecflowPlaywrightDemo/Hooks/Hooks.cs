﻿using Reqnroll;
using SpecflowPlaywrightDemo.Hooks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[Binding]
[Parallelizable(ParallelScope.Self)] // isolate scenarios
public class Hooks
{
    private readonly PlaywrightWorld _world;

    public Hooks(PlaywrightWorld world) => _world = world;

    // ---------- API-only setup ----------
    // Runs only for scenarios tagged @api
    [BeforeScenario("@api")]
    public async Task BeforeApiScenario()
    {
        if (_world.Playwright is null)
            _world.Playwright = await Microsoft.Playwright.Playwright.CreateAsync();

        if (_world.Api is null)
            _world.Api = await _world.Playwright.APIRequest.NewContextAsync();
    }



    // ---------- UI-only setup ----------
    // Runs only for scenarios tagged @ui
    [BeforeScenario("@ui")]
    public async Task BeforeUiScenario()
    {
        if (_world.Playwright is null)
            _world.Playwright = await Microsoft.Playwright.Playwright.CreateAsync();

        if (_world.Browser is null)
            _world.Browser = await _world.Playwright.Chromium.LaunchAsync(new() { Headless = false }); // set false if you prefer headed

        if (_world.Page is null)
            _world.Page = await _world.Browser.NewPageAsync();
    }

    [AfterScenario]
    public async Task AfterScenario()
    {
        if (_world.Page is not null) await _world.Page.CloseAsync();
        if (_world.Browser is not null) await _world.Browser.DisposeAsync();
        if (_world.Api is not null) await _world.Api.DisposeAsync();
        _world.Playwright?.Dispose();
    }
}
